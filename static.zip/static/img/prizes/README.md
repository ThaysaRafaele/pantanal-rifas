Coloque aqui a imagem de destaque para a seção 'Prêmios'.

Nome sugerido: premios-hero.png (1200x300 px recomendado)
Formato: png, jpg ou webp
Caminho final: static/img/prizes/premios-hero.png

Substitua o arquivo SVG atual por uma imagem com o nome sugerido ou atualize o src no template.
